package com.falguni.Multiplex_Seat_Booking_System._Backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultiplexSeatBookingSystemBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(MultiplexSeatBookingSystemBackendApplication.class, args);
		System.out.println("Hello, Falguni");
	}
}
