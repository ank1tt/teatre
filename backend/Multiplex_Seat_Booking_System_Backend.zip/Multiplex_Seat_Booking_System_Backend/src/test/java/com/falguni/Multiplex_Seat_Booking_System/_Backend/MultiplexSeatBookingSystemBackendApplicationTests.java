package com.falguni.Multiplex_Seat_Booking_System._Backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultiplexSeatBookingSystemBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
